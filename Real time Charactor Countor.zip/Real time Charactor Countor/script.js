const textArea = document.getElementById("textarea")
const totalCounter = document.getElementById("total-countor")
const remaining = document.getElementById("remaining-countor")

textArea.addEventListener("keyup",()=>{
    updateConunter()
    
})

function updateConunter(){
    totalCounter.innerHTML = textArea.value.length;
    remaining.innerHTML =   textArea.getAttribute("maxLength") - textArea.value.length;
}